local GLOBAL = _G or GLOBAL
GLOBAL.setmetatable(env, {
    __index = function(t, k)
        return GLOBAL.rawget(GLOBAL, k)
    end
})
-- your code starts here
